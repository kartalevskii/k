//EX1
    let num = [1, 2, 3, 4, 5];

for(let i = 0; i < num.length; i++) {
console.log(num[i]);
}

//EX2
    let chi = [-2, -1, -3, 15, 0, -4, 2, -5, 9, -15, 0, 4, 5, -6, 10, 7];

for (let i = 0; i< chi.length; i++) {
        if (chi[i] > -10 && chi[i] < -3) {
console.log(chi[i]); }
}

//EX3
    let arr = [];
    let i = 0;
    let result = 0;

for (let c = 23; c < 58; c++) {
    arr[i] = c;
    i++
    result += c;
}
console.log(arr);
console.log(result); 

//EX4
    let arrr = ['10', '20', '30', '50', '235', '3000'];
    let arr2 = [];

for (let i = 0; i < arrr.length; i++) {
if (arrr[i].charAt(0) == '1' || arrr[i].charAt(0) == '2' || arrr[i].charAt(0) == '5') {
arr2.push(arrr[i]);}
};
console.log(arr2);

//EX5
    let week = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'],
        str = '';

 for(let i = 0; i < week.length; i++) {
    if (week[i] == 'СБ') str += '<b>' + week[i] + '</b> ';
    else if (week[i] == 'ВС') str += '<b>' + week[i] + '</b> ';
    else str += week[i] + ' ';
    }
document.write(str);

//EX6    
    let words = ['раз', 'два', 3, '4', 5, 6, 'семь'];
    i = words.length;

    words.push(8);
console.log(words[i]);
    
//EX7
    let arrNum = [];

while(true) {
    let num = prompt('Введите числа');
    if (num != '') {
        arrNum.push(num);
    } else {
        break; }
    }
console.log(arrNum);
    arrNum.sort(function(a,b) {return a-b;});

//EX8
    let all = [12, false,'Текст', 4, 2, -5, 0];
all.reverse()
console.log(all);

//EX9
    let empty = [5, 9, 21, , , 9, 78, , , , 6];
        x = 0;

for(let i = 0; i < empty.length; i++) {
    if(empty[i] == undefined) x++; 
}
console.log(x);

//EX10

let last = [48,9,0,4,21,2,1,0,8,84,76,8,4,13,2],
    z1 = last.indexOf(0),
    z2 = last.lastIndexOf(0),
    sum = 0;

if (z1 != -1 && z2 != -2) {
    for(let i = z1; i <= z2; i++) {
        sum = sum + last[i];
}
console.log(sum); }

//EX11 попытка

    var lines = line = prompt('Введите число от 1 до 8'),
         a=' ', 
         b='^';
           
while(line-- > 0)
console.log(Array(line+1).join(a) + Array(2*(lines-line)).join(b) + Array(line+1).join(a)); 



    
  